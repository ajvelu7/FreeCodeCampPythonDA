import numpy as np

import numpy as np

def calculate(input_list):

    if len(input_list) != 9:
        raise ValueError("List must contain nine numbers.")
    
    array = np.array(input_list)
    reshaped_array = array.reshape(3, 3)

    # Rows
    first_row = reshaped_array[0]
    second_row = reshaped_array[1]
    third_row = reshaped_array[2]

    # Columns
    first_column = reshaped_array[:, 0]
    second_column = reshaped_array[:, 1]
    third_column = reshaped_array[:, 2]

    # Mean
    mean_rows = [float(first_row.mean()), float(second_row.mean()), float(third_row.mean())]
    mean_columns = [float(first_column.mean()), float(second_column.mean()), float(third_column.mean())]
    all_mean = float(array.mean())

    # Variance
    variance_rows = [float(first_row.var()), float(second_row.var()), float(third_row.var())]
    variance_columns = [float(first_column.var()), float(second_column.var()), float(third_column.var())]
    all_variance = float(array.var())

    # Standard Deviation
    std_rows = [float(first_row.std()), float(second_row.std()), float(third_row.std())]
    std_columns = [float(first_column.std()), float(second_column.std()), float(third_column.std())]
    all_std = float(array.std())

    # Max
    max_rows = [int(first_row.max()), int(second_row.max()), int(third_row.max())]
    max_columns = [int(first_column.max()), int(second_column.max()), int(third_column.max())]
    all_max = int(array.max())

    # Min
    min_rows = [int(first_row.min()), int(second_row.min()), int(third_row.min())]
    min_columns = [int(first_column.min()), int(second_column.min()), int(third_column.min())]
    all_min = int(array.min())

    # Sum
    sum_rows = [int(first_row.sum()), int(second_row.sum()), int(third_row.sum())]
    sum_columns = [int(first_column.sum()), int(second_column.sum()), int(third_column.sum())]
    all_sum = int(array.sum())

    # Final dictionary
    return {
        'mean': [mean_columns, mean_rows, all_mean],
        'variance': [variance_columns, variance_rows, all_variance],
        'std': [std_columns, std_rows, all_std],
        'max': [max_columns, max_rows, all_max],
        'min': [min_columns, min_rows, all_min],
        'sum': [sum_columns, sum_rows, all_sum],
    }
